package com.cg.cs.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.cs.entities.BookingDetail;
import com.cg.cs.entities.Hotel;
import com.cg.cs.entities.RoomDetail;
import com.cg.cs.entities.User;
import com.cg.cs.exception.CheapStaysException;
import com.cg.cs.service.ICheapStaysService;

@Controller
public class CheapStaysController {

	@Autowired
	private ICheapStaysService cheapStaysService;

	public ICheapStaysService getCheapStaysService() {
		return cheapStaysService;
	}

	public void setCheapStaysService(ICheapStaysService cheapStaysService) {
		this.cheapStaysService = cheapStaysService;
	}

	int noOfChildren = 0;
	int noOfAdults = 0;
	int noOfRooms = 0;
	int noOfDays = 0;
	double Totalamount1 = 0.0;
	double Totalamount2 = 0.0;
	Date date1;
	Date date2;
	String hotelname;

	@RequestMapping("/firstPage.obj")
	public String showFirstPage() {
		return "firstPage";
	}

	@RequestMapping("/index.obj")
	public String showLoginPage() {
		return "login";
	}

	@RequestMapping("/admin_home.obj")
	public String showPage() {
		return "admin_home";
	}

	@RequestMapping("/doLogin1.obj")
	public String homePage() {
		return "customerHome";
	}

	@RequestMapping("/report.obj")
	public String showReportPage() {
		return "reportPage";
	}

	@RequestMapping("/doLogin")
	public ModelAndView authenticateUser(
			@RequestParam("userName") String username,
			@RequestParam("password") String password, Model model) {
		ModelAndView mv;
		if (username.equals("Admin") && password.equals("Admin")) {
			mv = new ModelAndView();
			model.addAttribute("username", username);
			mv.setViewName("admin_home");
		} else {
			User user = new User();

			try {
				user.setUserName(username);
				user.setPassword(password);
				if (cheapStaysService.isValidUser(user) == true) {
					mv = new ModelAndView();
					mv.setViewName("customerHome");
				} else {
					String msg = "Wrong Credentials";
					mv = new ModelAndView();
					mv.setViewName("errorPage");
					mv.addObject("msg", msg);
					return mv;
				}
			} catch (CheapStaysException e) {
				mv = new ModelAndView();
				mv.setViewName("errorPage");
				return mv;
			}

		}
		return mv;
	}

	@RequestMapping("/register")
	public ModelAndView showAddUser() {
		User user = new User();
		return new ModelAndView("register", "user", user);
	}

	@RequestMapping("/addUser")
	public ModelAndView addUser(@ModelAttribute("user") @Valid User user,
			BindingResult result) throws CheapStaysException {

		ModelAndView mv = null;
		try {
			if (!result.hasErrors()) {

				user = cheapStaysService.addUser(user);
				if (user != null) {
					mv = new ModelAndView("successRegister");
					mv.addObject("userId", user.getUserId());
				} else {
					mv = new ModelAndView("errorPage");
					mv.addObject("msg", "Username already exist");
				}

			} else {
				mv = new ModelAndView("register", "user", user);
			}
		} catch (CheapStaysException e) {
			mv = new ModelAndView();
			mv.setViewName("errorPage");
			return mv;
		}
		return mv;
	}

	@RequestMapping("/hotel_management_home")
	public String showHotelPage() {
		return "hotel_management_home";
	}

	@RequestMapping("/add_hotel")
	public ModelAndView AddHotel() {
		Hotel hotel = new Hotel();
		return new ModelAndView("add_hotel", "hotel", hotel);
	}

	@RequestMapping("/addHotel")
	public ModelAndView addHotel(@ModelAttribute("hotel") @Valid Hotel hotel,
			BindingResult result) throws CheapStaysException {

		ModelAndView mv = null;

		if (!result.hasErrors()) {

			hotel = cheapStaysService.addHotel(hotel);
			mv = new ModelAndView("successAddHotel");
			mv.addObject("hotelId", hotel.getHotelId());

		} else {
			mv = new ModelAndView("add_hotel", "hotel", hotel);
		}

		return mv;
	}

	@RequestMapping("/modify_hotel")
	public ModelAndView updateHotel() {
		Hotel hotel = new Hotel();
		return new ModelAndView("modify_hotel", "hotel", hotel);
	}

	@RequestMapping("/confirmUpdate")
	public ModelAndView conformUpdateHotel(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result)
			throws CheapStaysException {

		ModelAndView mv = new ModelAndView();
		Hotel hotelBean = new Hotel();
		hotelBean = cheapStaysService.getHotel(hotel.getHotelId());

		if (hotelBean != null) {
			mv.setViewName("update_hotel");
			mv.addObject("hotelBean", hotelBean);
		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}

		return mv;

	}

	@RequestMapping("/confirmFinalUpdate")
	public ModelAndView updateHotel(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result)
			throws CheapStaysException {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			hotel = cheapStaysService.updateHotel(hotel);
			mv = new ModelAndView("successHotelUpdatePage");
			mv.addObject("hotelId", hotel.getHotelId());
		} else {
			System.out.println("sfsf");
			mv = new ModelAndView("update_hotel", "hotel", hotel);
		}

		return mv;
	}

	@RequestMapping("/delete_hotel")
	public ModelAndView deleteHotel() {
		ModelAndView mv = new ModelAndView();
		try {
			List<Hotel> list = cheapStaysService.getAllHotels();
			if (list.isEmpty()) {
				String msg = "There are no Hotels";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("delete_hotel");
				mv.addObject("list", list);
			}
		} catch (CheapStaysException e) {
			String msg = "Some error has occured";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/confirm_Delete")
	public ModelAndView deletePage(@RequestParam("hotelId") int hotelId,
			Model model) {
		ModelAndView mv = new ModelAndView();
		try {
			Hotel hotel = cheapStaysService.getHotel(hotelId);
			List<Hotel> list = cheapStaysService.getAllHotels();
			 cheapStaysService.deleteHotel(hotel);
			mv = new ModelAndView("delete_hotel");
			if (list.isEmpty()) {
				String msg = "No hotels to display";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);

			} else {
				mv.addObject("list", list);
				mv.addObject("hotelId", hotelId);
				mv.setViewName("deleteHotelSuccessful");
			}

		} catch (CheapStaysException e) {
			String msg = "Some error has occured";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/showViewAllHotels")
	public ModelAndView showViewAllHotels() {

		ModelAndView mv = new ModelAndView();

		try {
			List<Hotel> list = cheapStaysService.getAllHotels();
			Hotel hotel = new Hotel();
			RoomDetail room = new RoomDetail();

			if (list.isEmpty()) {
				String msg = "There are no Hotels";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewAllHotels");
				// Add the attribute to the model
				mv.addObject("list", list);
				mv.addObject("hotel", hotel);
				mv.addObject("room", room);
			}
		} catch (CheapStaysException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping("/viewAllHotelsReport")
	public ModelAndView viewAllHotelsReport() {

		ModelAndView mv = new ModelAndView();
		RoomDetail room = new RoomDetail();

		try {
			List<Hotel> list = cheapStaysService.getAllHotels();
			Hotel hotel = new Hotel();

			if (list.isEmpty()) {
				String msg = "There are no Hotels";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewAllHotelsReport");
				mv.addObject("list", list);
				mv.addObject("hotel", hotel);
				mv.addObject("room", room);
			}
		} catch (CheapStaysException e) {
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping("/showAddRoomForm")
	public ModelAndView showAddRoom(
			@ModelAttribute("hotel") @Valid Hotel hotel, BindingResult result)
			throws CheapStaysException {
		RoomDetail room = new RoomDetail();
		ModelAndView mv = new ModelAndView();
		Hotel hotelBean = new Hotel();
		hotelBean = cheapStaysService.getHotel(hotel.getHotelId());
		if (hotelBean != null) {
			mv.setViewName("addRoomForm");
			mv.addObject("hotelBean", hotelBean);
			mv.addObject("room", room);
		}

		return mv;
	}

	@RequestMapping("/addRoom")
	public ModelAndView addRoom(@ModelAttribute("room") @Valid RoomDetail room,
			BindingResult result) {
		Hotel hotel = new Hotel();
		ModelAndView mv = null;

		if (!result.hasErrors()) {
			try {
				room = cheapStaysService.addRoom(room);
			} catch (CheapStaysException e) {
				e.printStackTrace();
			}
			mv = new ModelAndView("addRoomSuccess");
			mv.addObject("hotelId", hotel.getHotelId());
			mv.addObject("roomId", room.getRoomId());
		} else {
			mv = new ModelAndView("addRoomForm", "room", room);
		}

		return mv;
	}

	@RequestMapping("/showViewAllRooms")
	public ModelAndView showViewAllRooms(
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result) {

		ModelAndView mv = new ModelAndView();
		try {

			List<RoomDetail> list = cheapStaysService.getAllRoomsById(room
					.getHotelId());

			if (list.isEmpty()) {
				String msg = "There are no Rooms";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewAllRooms");
				// Add the attribute to the model
				mv.addObject("list", list);
				/* mv.addObject("room",room); */
			}
		} catch (CheapStaysException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping("/viewAllRoomsReport")
	public ModelAndView showViewAllRoomsReport(
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result) {

		ModelAndView mv = new ModelAndView();
		try {

			List<RoomDetail> list = cheapStaysService.getAllRoomsById(room
					.getHotelId());

			if (list.isEmpty()) {
				String msg = "There are no Rooms";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewAllRoomsReport");
				// Add the attribute to the model
				mv.addObject("list", list);

			}
		} catch (CheapStaysException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping("/showUpdateRoomForm")
	public ModelAndView showAddRoom(
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result)
			throws CheapStaysException {
		ModelAndView mv = new ModelAndView();
		RoomDetail roomBean = new RoomDetail();
		roomBean = cheapStaysService.getRoom(room.getRoomId());
		if (roomBean != null) {
			mv.setViewName("updateRoom");
			mv.addObject("roomBean", roomBean);
		}

		// room.setHotel(hotel);
		return mv;
	}

	@RequestMapping("/updateRoom")
	public ModelAndView updateRoom(
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result) {

		ModelAndView mv = null;

		if (!result.hasErrors()) {
			try {
				room = cheapStaysService.updateRoom(room);
			} catch (CheapStaysException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			mv = new ModelAndView("updateRoomSuccess");
			mv.addObject("roomId", room.getRoomId());
		} else {
			mv = new ModelAndView("updateRoom", "room", room);
		}

		return mv;
	}

	@RequestMapping("/showViewAllRoomsForDelete")
	public ModelAndView showViewAllRoomsForDelete(
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result) {

		ModelAndView mv = new ModelAndView();

		try {
			List<RoomDetail> list = cheapStaysService.getAllRoomsById(room
					.getHotelId());

			if (list.isEmpty()) {
				String msg = "There are no Rooms";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewAllRoomsForDelete");
				// Add the attribute to the model
				mv.addObject("list", list);
				mv.addObject("room", room);
			}
		} catch (CheapStaysException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping("/deleteRoom")
	public ModelAndView deleTrainee(@ModelAttribute("room") RoomDetail room) {

		ModelAndView mv = new ModelAndView();

		try {
			room = cheapStaysService.deleteRoom(room.getRoomId());
		} catch (CheapStaysException e) {
			String msg = "Some error has occured";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}

		if (room != null) {
			mv.setViewName("deleteRoomSuccessful");
			mv.addObject("room", room);
		} else {
			String msg = "Details not deleted";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}

		return mv;
	}

	@RequestMapping("/viewHotelsByCity")
	public ModelAndView searchPage() {

		Hotel hotel = new Hotel();
		// Add the attribute to the model and set the view name and return it
		return new ModelAndView("custWelcome", "hotel", hotel);
	}
	
	@RequestMapping("/custWelcome")
	public ModelAndView custWelcome() {

		Hotel hotel = new Hotel();
		// Add the attribute to the model and set the view name and return it
		return new ModelAndView("custWelcome", "hotel", hotel);
	}

	@RequestMapping("/search")
	public ModelAndView showHotelsByCity(@RequestParam("cityname") String city,
			@RequestParam("nr") int nr, @RequestParam("adult") int adult,
			@RequestParam("child") int child,
			@RequestParam("from") String fromDate,
			@RequestParam("to") String toDate) throws CheapStaysException {
		ModelAndView mv = new ModelAndView();
		noOfAdults = adult;
		noOfChildren = child;
		noOfRooms = nr;
		LocalDate localDate;
		SimpleDateFormat myFormat = new SimpleDateFormat("dd/MM/yyyy");
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		try {
			date1 = myFormat.parse(fromDate);
			date2 = myFormat.parse(toDate);
			long diff = (date2.getTime() - date1.getTime()) / 86400000;
			Long obj = new Long(diff);
			int days = obj.intValue();

			noOfDays = days;
			localDate=LocalDate.parse(fromDate, dateTimeFormatter);
			List<Hotel> list = cheapStaysService.getHotelByCity(city);
	        if(cheapStaysService.isValidBookingFromDate(localDate)) {
			if(date1.compareTo(date2)<0) {
			if (list.isEmpty()) {
				String msg = "Enter a Valid City!!";
				mv.setViewName("errorPage1");
				mv.addObject("msg", msg);
			} else {

				mv.setViewName("hotelListByCity");
				mv.addObject("list", list);
			}
			} 			else {
				String msg = "Please enter check in and check out dates properly";
				mv.setViewName("errorPage1");
				mv.addObject("msg", msg);
			}
		} else {
			String msg = "Please enter correct date";
			mv.setViewName("errorPage1");
			mv.addObject("msg", msg);
		}
		} catch (ParseException e) {
			String msg = "Please enter Valid date(dd/MM/yyyy)";
			mv.setViewName("errorPage1");
			mv.addObject("msg", msg);
		}

		return mv;
	}
	@RequestMapping("/viewRoomForBooking")
	public ModelAndView showviewRoomForBookingReport(
			@ModelAttribute("room") @Valid RoomDetail room, BindingResult result) {

		ModelAndView mv = new ModelAndView();
		try {

			List<RoomDetail> list = cheapStaysService.getAllRoomsById(room
					.getHotelId());

			if (list.isEmpty()) {
				String msg = "There are no Rooms";
				mv.setViewName("errorPage");
				mv.addObject("msg", msg);
			} else {
				mv.setViewName("viewRoomForBooking");
				mv.addObject("list", list);

			}
		} catch (CheapStaysException e) {
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping("/bookRoom")
	public ModelAndView bookroom(@RequestParam("hotelId") int hotelId,
			@RequestParam("roomId") int roomId,
			@ModelAttribute("RoomDetail") @Valid RoomDetail RoomDetail,
			BindingResult result) throws CheapStaysException {
		
		List<RoomDetail> list = cheapStaysService.getAllRoomsById(hotelId);
		
		Map<String, Double> mapPrice = new HashMap<String, Double>();
		ModelAndView mv = new ModelAndView();
		mapPrice = cheapStaysService.getPrice(roomId);
		if (!mapPrice.isEmpty()) {
			mv.addObject("mapPrice", mapPrice);
			mv.setViewName("bookNow");
		} else {
			String msg = "Enter a Valid City!!";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}
		return mv;
	}

	@RequestMapping("/payment")
	public ModelAndView PaymentPage(@RequestParam("rpn") double rpn) {
		ModelAndView mv = new ModelAndView("payment");
		mv.addObject("noOfAdults", noOfAdults);
		double amount1 = ((noOfChildren) * rpn / 3 * noOfDays + (rpn * noOfDays))
				* noOfRooms;
		double amount2 = noOfRooms
				* noOfDays
				* (((noOfChildren) * rpn / 3) + (rpn + ((noOfAdults - 2) * rpn * 0.3)));
		Totalamount1 = amount1;
		Totalamount2 = amount2;
		mv.addObject("amount1", amount1);
		mv.addObject("amount2", amount2);

		mv.addObject("noOfDays", noOfDays);
		return mv;
	}

	@RequestMapping("/confirm")
	public ModelAndView ConfirmationPage() throws CheapStaysException {
		BookingDetail bookingDetail = new BookingDetail();

		bookingDetail.setBookedFrom(date1);
		bookingDetail.setBookedTo(date2);
		bookingDetail.setAmount1(Totalamount1);
		bookingDetail.setAmount2(Totalamount2);
		bookingDetail.setNoOfAdults(noOfAdults);
		bookingDetail.setNoOfChildren(noOfChildren);
		bookingDetail.setHotelName(hotelname);
		int bookingId = cheapStaysService.bookRoom(bookingDetail)
				.getBookingId();
		ModelAndView mv = new ModelAndView("confirmation");
		mv.addObject("noOfAdults", noOfAdults);
		mv.addObject("Totalamount1", Totalamount1);
		mv.addObject("Totalamount2", Totalamount2);
		mv.addObject("noOfDays", noOfDays);
		mv.addObject("bookingId", bookingId);
		return mv;
	}

	@RequestMapping("/viewBooking")
	public String statusPage() {
		return "book_status";
	}

	@RequestMapping("/confirm_status")
	public ModelAndView finalstatus(
			@RequestParam("bookingId") int bookingId,
			@ModelAttribute("bookingdetails") @Valid BookingDetail bookingDetail,
			BindingResult result) throws CheapStaysException {

		ModelAndView mv = new ModelAndView();
		BookingDetail bbean = new BookingDetail();
		bbean = cheapStaysService.bookingStatus(bookingId);

		if (bbean != null) {
			mv.setViewName("bookingStatus");
			String date12 = new SimpleDateFormat("dd-MMM-yyyy").format(bbean
					.getBookedFrom());
			String date22 = new SimpleDateFormat("dd-MMM-yyyy").format(bbean
					.getBookedTo());
			mv.addObject("date12", date12);
			mv.addObject("date22", date22);
			mv.addObject("bbean", bbean);

		} else {
			String msg = "Enter a Valid Id!!";
			mv.setViewName("errorPage");
			mv.addObject("msg", msg);
		}

		return mv;

	}

}

package com.cg.cs.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.cs.entities.BookingDetail;
import com.cg.cs.entities.Hotel;
import com.cg.cs.entities.RoomDetail;
import com.cg.cs.entities.User;
import com.cg.cs.exception.CheapStaysException;


@Repository
public class CheapStaysDaoImpl implements ICheapStaysDao {

	@PersistenceContext
	EntityManager entityManager;
	@Override
	public User addUser(User user) throws CheapStaysException {
		TypedQuery<User> query= entityManager.createQuery("SELECT user FROM User user WHERE user.userName =:puserName",User.class);
		query.setParameter("puserName", user.getUserName());
		List<User> list = query.getResultList();
		
		
		if(list.isEmpty()){
			entityManager.persist(user);
			entityManager.flush();
			return user;
		}
		else
			return null;
	}
	

	@Override
	public boolean isValidUser(User user) throws CheapStaysException {		
		TypedQuery<User> query= entityManager.createQuery("SELECT user FROM User user WHERE user.userName LIKE :puserName and user.password LIKE :ppassword",User.class);
		query.setParameter("puserName", user.getUserName());
		query.setParameter("ppassword", user.getPassword());
		User user1 = new User();
		try{
		user1 = query.getSingleResult();
		if(user1 != null){
			return true;
		}
		else
			return false;
		}catch(NoResultException e){
			return false;
		}
		}

	@Override
	public Hotel addHotel(Hotel hotel) throws CheapStaysException {
		entityManager.persist(hotel);
		entityManager.flush();
		return hotel;
	}

	
	@Override
	public Hotel updateHotel(Hotel hotel) throws CheapStaysException {
		entityManager.merge(hotel);
		entityManager.flush();
		return hotel;
	}

	@Override
	public Hotel getHotel(int hotelId) throws CheapStaysException {
		 return entityManager.find(Hotel.class, hotelId);
	}

	@Override
	public List<Hotel> getAllHotels() throws CheapStaysException {
		TypedQuery<Hotel> query = entityManager.createQuery("SELECT h FROM Hotel h", Hotel.class);
		return query.getResultList();
	}

	@Override
	public void deleteHotel(Hotel hotel) throws CheapStaysException {
		entityManager.remove(hotel);
	}
	@Override
	public RoomDetail addRoom(RoomDetail room) throws CheapStaysException {
		entityManager.persist(room);
		entityManager.flush();
		return room;
	}

	@Override
	public List<RoomDetail> getAllRooms() throws CheapStaysException {
		TypedQuery<RoomDetail> query =
				 entityManager.createQuery("SELECT r1 FROM RoomDetail r1",RoomDetail.class);
				return query.getResultList();
	}

	@Override
	public RoomDetail getRoom(int roomId) throws CheapStaysException {
		 return entityManager.find(RoomDetail.class, roomId);
	}

	@Override
	public RoomDetail updateRoom(RoomDetail room) throws CheapStaysException {
		entityManager.merge(room);
		entityManager.flush();
		return room;
	}

	@Override
	public RoomDetail deleteRoom(int roomId) throws CheapStaysException {
		RoomDetail room = getRoom(roomId);
		entityManager.remove(room);
		return room;
	}

	@Override
	public List<Hotel> getHotelByCity(String city) throws CheapStaysException {
		TypedQuery<Hotel> query=entityManager.createQuery("Select hotel from Hotel hotel where hotel.city LIKE :pcity",Hotel.class);
		query.setParameter("pcity","%"+city+"%");
		return query.getResultList();
	}

	@Override
	public Map<String, Double> getPrice(int roomId ) throws CheapStaysException {
		Map<String, Double> mapPrice = new HashMap<String,Double>();
		TypedQuery<RoomDetail> query= entityManager.createQuery("SELECT roomDetail from RoomDetail roomDetail where roomDetail.roomId = :proomId ",RoomDetail.class);
		query.setParameter("proomId",roomId);
		RoomDetail rd = new RoomDetail();
		rd = query.getSingleResult();
		String roomKey = rd.getRoomType();
		double roomValue  = rd.getPerNightRate();
		mapPrice.put(roomKey,roomValue);
		return mapPrice;
	}

	@Override
	public BookingDetail bookRoom(BookingDetail bookingDetail) throws CheapStaysException {
		entityManager.persist(bookingDetail);
		entityManager.flush();
		return bookingDetail;
	}

	@Override
	public BookingDetail bookingStatus(int bookingId) throws CheapStaysException {
		// TODO Auto-generated method stub
		return entityManager.find(BookingDetail.class, bookingId);
		
	}

	@Override
	public List<RoomDetail> getAllRoomsById(int hotelId)
			throws CheapStaysException {
		TypedQuery<RoomDetail> query=entityManager.createQuery("Select r from RoomDetail r where r.hotelId = :photelId ",RoomDetail.class);
		query.setParameter("photelId",hotelId);
		return query.getResultList();
	}


}
